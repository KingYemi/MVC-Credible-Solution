﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Credible.Core.Interfaces;
using Credible.Core.Model;
using Credible.Core.Services;
using Credible.Data.DBContext;
using Credible.Data.Repository;

namespace Credible.Web.Controllers
{
    public class PortalClientsController : Controller
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IClientService _clientService;

        public PortalClientsController(IClientService clientService)
        {
            _clientService = clientService ?? throw new ArgumentException("ClientService is null");
        }

        // GET: PortalClients
        public ActionResult Index()
        {
            try
            {
                var clients = _clientService.GetAll();
                return View(clients);
            }
            catch (Exception)
            {
                log.Error("PortalController:Index Error occured!");
                return View("Error");
            }
        }

        //// POST: PortalClients/Edit/5
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit([Bind(Include = "Id,ClientName")] PortalClient portalClient)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(portalClient).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(portalClient);
        //}
    }
}
