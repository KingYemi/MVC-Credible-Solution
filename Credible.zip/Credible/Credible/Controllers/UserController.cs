﻿using Credible.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Credible.Web.Controllers
{
    public class UserController : Controller
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService ?? throw new ArgumentException("UserService is null");
        }

        [HttpGet]
        public ActionResult GetById(int courseId, int pageIdx, int maxCount, int totalRecords)
        {
            try
            {
                var userRecords = _userService.GetUsersByCourseId(courseId, pageIdx, maxCount, totalRecords);
                return PartialView("_Students", userRecords);
            }
            catch (Exception)
            {
                log.Error("UserController:GetById Error occured!");
                return View();
            }
        }
    }
}