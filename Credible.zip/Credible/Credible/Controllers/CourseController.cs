﻿using Credible.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Credible.Web.Controllers
{
    public class CourseController : Controller
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly ICourseService _courseService;

        public CourseController(ICourseService clientService)
        {
            _courseService = clientService ?? throw new ArgumentException("CourseService is null");
        }

        
        public ActionResult Index(int portalId)
        {
            try
            {
                var courses = _courseService.GetCoursesByPortalId(portalId);
                return View(courses);
            }
            catch (Exception)
            {
                log.Error("CourseController:Index Error occured!");
                return View("Error");
            }
        }
    }
}