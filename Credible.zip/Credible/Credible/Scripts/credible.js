﻿
var currentPage = 1;
function getUsers(c_portalId, pageIdx, maxRows) {
    $.ajax({
        url: '/User/GetById',
        datatype: "html",
        type: "get",
        data: { courseId: c_portalId, pageIdx: pageIdx, maxCount: maxRows, totalRecords: $('#hfTotalRecords').val() },
        contenttype: 'application/json; charset=utf-8',
        success: function (html) {
            $('#modalContent').html(html);
            $('#tblrecords').each(function () {
                $("tr:even").css("background-color", "whitesmoke");
            });
            $('#myModal').show();
        },
        error: function (xhr) {

        }
    });
}