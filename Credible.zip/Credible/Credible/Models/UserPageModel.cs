﻿using Credible.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Credible.Web.Models
{
    public class UserPageModel
    {
        public List<UserRegistrationRecords> UserList { get; set; }
        public int TotalUserCount { get; set; }
        public int MaxRows { get; set; }

        public int CurrentPage { get; set; }

        public int PageCount
        {
            get
            {
                if( TotalUserCount % MaxRows == 0)
                {
                    return (TotalUserCount / MaxRows);
                }
                return (TotalUserCount / MaxRows) + 1;
            }
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public UserPageModel()
        {
            UserList = new List<UserRegistrationRecords>();
            MaxRows = 25;
        }
    }
}