using System.Data.Entity;
using System.Web.Mvc;
using Credible.Core.Interfaces;
using Credible.Core.Services;
using Credible.Data.DBContext;
using Credible.Data.Repository;
using Microsoft.Practices.Unity;
using Unity.Mvc4;

namespace Credible.Web
{
  public static class Bootstrapper
  {
    public static IUnityContainer Initialise()
    {
      var container = BuildUnityContainer();

      DependencyResolver.SetResolver(new UnityDependencyResolver(container));

      return container;
    }

    private static IUnityContainer BuildUnityContainer()
    {
      var container = new UnityContainer();

            container.RegisterType<DbContext,DataContext>();
            container.RegisterType<IUserRepository,UserRepository>();
            container.RegisterType<IClientRepository,ClientRepository>();
            container.RegisterType<ICourseRepository,CourseRepository>();

            container.RegisterType<IUserService,UserService>();
            container.RegisterType<IClientService,ClientService>();
            container.RegisterType<ICourseService,CourseService>();
          
      RegisterTypes(container);

      return container;
    }

    public static void RegisterTypes(IUnityContainer container)
    {
    
    }
  }
}