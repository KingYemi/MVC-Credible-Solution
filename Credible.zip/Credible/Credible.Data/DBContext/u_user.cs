namespace Credible.Data.DBContext
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class u_user
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public u_user()
        {
            u_registration = new HashSet<u_registration>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int user_id { get; set; }

        public Guid UserId { get; set; }

        public int? client_id { get; set; }

        [StringLength(256)]
        public string company_nm { get; set; }

        [StringLength(128)]
        public string title { get; set; }

        [StringLength(128)]
        public string department { get; set; }

        [StringLength(128)]
        public string first_nm { get; set; }

        [StringLength(128)]
        public string last_nm { get; set; }

        [StringLength(32)]
        public string phone1 { get; set; }

        [StringLength(32)]
        public string phone2 { get; set; }

        [StringLength(32)]
        public string fax { get; set; }

        [StringLength(128)]
        public string address1 { get; set; }

        [StringLength(128)]
        public string address2 { get; set; }

        [StringLength(128)]
        public string city { get; set; }

        public int? county_id { get; set; }

        [StringLength(128)]
        public string state { get; set; }

        [StringLength(15)]
        public string postal_cd { get; set; }

        [StringLength(128)]
        public string sec_address1 { get; set; }

        [StringLength(128)]
        public string sec_address2 { get; set; }

        [StringLength(128)]
        public string sec_city { get; set; }

        [StringLength(128)]
        public string sec_state { get; set; }

        [StringLength(15)]
        public string sec_postal_cd { get; set; }

        public bool speaker_ind { get; set; }

        public bool marketing_partner_ind { get; set; }

        public bool credit_grantor_ind { get; set; }

        public bool direct_buyer_ind { get; set; }

        public bool active_ind { get; set; }

        public DateTime created_dttm { get; set; }

        public int created_id { get; set; }

        public DateTime? modified_dttm { get; set; }

        public int? modified_id { get; set; }

        public bool notification_email_ind { get; set; }

        public int? subject_id { get; set; }

        public int? grade_level_id { get; set; }

        public int? position_id { get; set; }

        public bool temp_pwd_changed { get; set; }

        public DateTime? user_agreement_accept_dttm { get; set; }

        [StringLength(50)]
        public string district_employee_id { get; set; }

        [StringLength(50)]
        public string state_employee_id { get; set; }

        [StringLength(64)]
        public string group_nm { get; set; }

        public bool review_mode_ind { get; set; }

        public bool chat_ind { get; set; }

        [StringLength(12)]
        public string soc_sec_nmb { get; set; }

        public DateTime? date_of_birth { get; set; }

        [StringLength(256)]
        public string avatar_url { get; set; }

        [StringLength(256)]
        public string thumbnail_url { get; set; }

        public int clustered_id { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<u_registration> u_registration { get; set; }
    }
}
