namespace Credible.Data.DBContext
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DataContext : DbContext
    {
        public DataContext()
            : base("name=DataContext")
        {
        }
        
        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<u_course_portal> u_course_portal { get; set; }
        public virtual DbSet<u_portal> u_portal { get; set; }
        public virtual DbSet<u_registration> u_registration { get; set; }
        public virtual DbSet<u_user> u_user { get; set; }
        public virtual DbSet<test> tests { get; set; }
        public virtual DbSet<course> courses { get; set; }
        public virtual DbSet<user> users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.credit_type_cd)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.credit_type_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.earned_credit)
                .HasPrecision(3, 1);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.syllabus)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.syllabus_url)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.regular_px)
                .HasPrecision(13, 4);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.sale_px)
                .HasPrecision(13, 4);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.sort_order)
                .HasPrecision(10, 4);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.deployment_status)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.course_portal_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.course_display_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.course_display_img)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.course_subject)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.course_topic)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.course_default_standard)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.upgrade_price)
                .HasPrecision(12, 4);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.upgrade_overview)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .Property(e => e.credit_acceptance)
                .IsUnicode(false);

            modelBuilder.Entity<u_course_portal>()
                .HasMany(e => e.u_registration)
                .WithRequired(e => e.u_course_portal)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.portal_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.notes)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.title)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.keyword)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.description)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.introduction)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.promotion)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.data)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.completion)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.flyer_url)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.logo_url)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.logo)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.contact_email)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.theme)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.login_page_logo)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.login_page_text)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .Property(e => e.eClassroom_logo)
                .IsUnicode(false);

            modelBuilder.Entity<u_portal>()
                .HasMany(e => e.u_course_portal)
                .WithRequired(e => e.u_portal)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<u_registration>()
                .Property(e => e.registration_type_cd)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<u_registration>()
                .Property(e => e.final_grade)
                .HasPrecision(12, 4);

            modelBuilder.Entity<u_user>()
                .Property(e => e.company_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.title)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.department)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.first_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.last_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.phone1)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.phone2)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.fax)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.address1)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.address2)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.city)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.state)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.postal_cd)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.sec_address1)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.sec_address2)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.sec_city)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.sec_state)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.sec_postal_cd)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.district_employee_id)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.state_employee_id)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.group_nm)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.soc_sec_nmb)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.avatar_url)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .Property(e => e.thumbnail_url)
                .IsUnicode(false);

            modelBuilder.Entity<u_user>()
                .HasMany(e => e.u_registration)
                .WithRequired(e => e.u_user)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<test>()
                .Property(e => e.TestName)
                .IsUnicode(false);

            modelBuilder.Entity<course>()
                .Property(e => e.course_portal_nm)
                .IsUnicode(false);

            modelBuilder.Entity<user>()
                .Property(e => e.first_nm)
                .IsUnicode(false);

            modelBuilder.Entity<user>()
                .Property(e => e.last_nm)
                .IsUnicode(false);
        }
    }
}
