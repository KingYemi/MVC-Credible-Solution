namespace Credible.Data.DBContext
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class u_course_portal
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public u_course_portal()
        {
            u_registration = new HashSet<u_registration>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int course_portal_id { get; set; }

        public int portal_id { get; set; }

        public int course_variant_id { get; set; }

        [Required]
        [StringLength(4)]
        public string credit_type_cd { get; set; }

        [StringLength(128)]
        public string credit_type_nm { get; set; }

        public decimal earned_credit { get; set; }

        [Column(TypeName = "text")]
        public string syllabus { get; set; }

        [StringLength(256)]
        public string syllabus_url { get; set; }

        public decimal regular_px { get; set; }

        public decimal? sale_px { get; set; }

        public decimal sort_order { get; set; }

        public bool forum_ind { get; set; }

        public int classroom_sz { get; set; }

        public int? forum_posts_per_topic { get; set; }

        public DateTime display_start_dt { get; set; }

        public DateTime display_finish_dt { get; set; }

        public DateTime purchase_start_dt { get; set; }

        public DateTime purchase_finish_dt { get; set; }

        public DateTime access_start_dt { get; set; }

        public DateTime? access_finish_dt { get; set; }

        public int? access_day { get; set; }

        public bool active_ind { get; set; }

        public DateTime created_dttm { get; set; }

        public int created_id { get; set; }

        public DateTime? modified_dttm { get; set; }

        public int? modified_id { get; set; }

        public int grade_id { get; set; }

        public string deployment_status { get; set; }

        public int? reg_method { get; set; }

        [StringLength(256)]
        public string course_portal_nm { get; set; }

        public bool self_reg_enabled_ind { get; set; }

        [StringLength(256)]
        public string course_display_nm { get; set; }

        public string course_display_img { get; set; }

        [StringLength(256)]
        public string course_subject { get; set; }

        [StringLength(256)]
        public string course_topic { get; set; }

        [StringLength(256)]
        public string course_default_standard { get; set; }

        public bool? credit_upgrade_ind { get; set; }

        public decimal? upgrade_price { get; set; }

        public string upgrade_overview { get; set; }

        public bool enable_evidence { get; set; }

        public string credit_acceptance { get; set; }

        public int clustered_id { get; set; }

        public virtual u_portal u_portal { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<u_registration> u_registration { get; set; }
    }
}
