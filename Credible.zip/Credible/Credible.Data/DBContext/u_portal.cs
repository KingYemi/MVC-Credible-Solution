namespace Credible.Data.DBContext
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class u_portal
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public u_portal()
        {
            u_course_portal = new HashSet<u_course_portal>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int portal_id { get; set; }

        [Required]
        [StringLength(256)]
        public string portal_nm { get; set; }

        public int? client_id { get; set; }

        public int? state_id { get; set; }

        public int? agency_id { get; set; }

        public int? school_id { get; set; }

        public int portal_type_id { get; set; }

        public bool marketing_partner_ind { get; set; }

        public bool credit_grantor_ind { get; set; }

        public int? other_credit_grantor_id { get; set; }

        public bool direct_buyer_ind { get; set; }

        [Column(TypeName = "text")]
        public string notes { get; set; }

        public DateTime display_start_dt { get; set; }

        public DateTime display_finish_dt { get; set; }

        public DateTime purchase_start_dt { get; set; }

        public DateTime purchase_finish_dt { get; set; }

        public DateTime access_start_dt { get; set; }

        public DateTime? access_finish_dt { get; set; }

        public int? access_day { get; set; }

        [Column(TypeName = "text")]
        public string title { get; set; }

        [Column(TypeName = "text")]
        public string keyword { get; set; }

        [Column(TypeName = "text")]
        public string description { get; set; }

        [Column(TypeName = "text")]
        public string introduction { get; set; }

        [Column(TypeName = "text")]
        public string promotion { get; set; }

        [Column(TypeName = "text")]
        public string data { get; set; }

        [Column(TypeName = "text")]
        public string completion { get; set; }

        [StringLength(256)]
        public string flyer_url { get; set; }

        [StringLength(256)]
        public string logo_url { get; set; }

        [StringLength(1024)]
        public string logo { get; set; }

        [StringLength(256)]
        public string contact_email { get; set; }

        public bool active_ind { get; set; }

        public DateTime created_dttm { get; set; }

        public int created_id { get; set; }

        public DateTime? modified_dttm { get; set; }

        public int? modified_id { get; set; }

        public Guid? RoleId { get; set; }

        [StringLength(64)]
        public string theme { get; set; }

        [StringLength(100)]
        public string login_page_logo { get; set; }

        [StringLength(250)]
        public string login_page_text { get; set; }

        public bool? special_use { get; set; }

        public bool self_reg_ind { get; set; }

        public bool? self_reg_limit_by_teacher { get; set; }

        [StringLength(250)]
        public string eClassroom_logo { get; set; }

        public int? self_reg_teacher_course_limit { get; set; }

        public bool chat_ind { get; set; }

        public bool pwd_change_rqd_ind { get; set; }

        public bool review_mode_ind { get; set; }

        public bool? only_grade_complete_ind { get; set; }

        public int clustered_id { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<u_course_portal> u_course_portal { get; set; }
    }
}
