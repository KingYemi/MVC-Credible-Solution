namespace Credible.Data.DBContext
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("course")]
    public partial class course
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int portal_id { get; set; }

        [StringLength(256)]
        public string course_portal_nm { get; set; }
    }
}
