﻿using Credible.Core.Interfaces;
using Credible.Core.Model;
using Credible.Data.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Data.Repository
{
    public class CourseRepository : ICourseRepository
    {
        private readonly DataContext Context;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public CourseRepository(DataContext context)
        {
            Context = context;
        }
        public IEnumerable<Course> GetCoursesByPortalId(int portalId)
        {
            try
            {
                var courses = (from cp in Context.u_course_portal
                               where cp.portal_id == portalId
                               select new Course
                               {
                                   CourseId = cp.course_portal_id,
                                   CourseName = cp.course_portal_nm
                               }).ToList();

                return courses;
            }
            catch (Exception)
            {
                log.Error($"GetCoursesByPortalId: Error retrieving data for portalId {portalId}");
                return new List<Course>();
            }
        }
    }
}
