﻿using Credible.Core.Interfaces;
using Credible.Core.Model;
using Credible.Data.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Data.Repository
{
    public class UserRepository : IUserRepository
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly DataContext Context;

        public UserRepository(DataContext context)
        {
            Context = context;
        }

        public UserRegistrationRecords GetUsersByCourseId(int coursePortalId, int pageIdx, int maxRows, int totalRecords)
        {
            var userRecords = new UserRegistrationRecords();
            try
            {
                userRecords.TotalRecords = totalRecords;
                if (totalRecords == 0)
                {
                    totalRecords = (from ur in Context.u_registration
                                 join usr in Context.u_user on ur.user_id equals usr.user_id
                                 where ur.course_portal_id == coursePortalId
                                 select ur.user_id).Count();
                }

                //update the total records returned
                //
                userRecords.TotalRecords = totalRecords;

                var users = (from ur in Context.u_registration
                             join usr in Context.u_user on ur.user_id equals usr.user_id
                             where ur.course_portal_id == coursePortalId 
                             select new User
                             {
                                 UserId = ur.user_id,
                                 CoursePortalId = coursePortalId,
                                 FirstName = usr.first_nm,
                                 LastName =  usr.last_nm,
                                 RegistrationDate = ur.registration_dttm
                             })
                             .OrderBy(user => user.UserId)
                             .Skip((pageIdx - 1) * maxRows)
                             .Take(maxRows).ToList();

                userRecords.UserRecords = users;
                return userRecords;
            }
            catch(Exception ex)
            {
                log.Error($"UserRepository coursePortalId: Error retrieving user records");
                return new UserRegistrationRecords();
            }
        }
    }
}
