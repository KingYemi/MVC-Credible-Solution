﻿using Credible.Core.Interfaces;
using Credible.Core.Model;
using Credible.Data.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Credible.Data.Repository
{
    public class ClientRepository : IClientRepository
    {
        private readonly DataContext Context;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        public ClientRepository(DataContext context)
        {
            Context = context;
        }

        public IEnumerable<PortalClient> GetAll()
        {
            try
            {
                var clients = (from up in Context.u_portal
                             select new PortalClient
                             {
                                 Id = up.portal_id,
                                 ClientName = up.portal_nm
                             })
                             .OrderBy(c => c.ClientName)
                             .ToList();
                return clients;
            }
            catch (Exception)
            {
                log.Error($"ClientRepository GetAll: Error retrieving data");
                return new List<PortalClient>();
            }
        }
    }
}
