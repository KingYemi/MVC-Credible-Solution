﻿using Credible.Core.Interfaces;
using Credible.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Core.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientRepository _clientRepo;

        public ClientService(IClientRepository clientRepo)
        {
            _clientRepo = clientRepo ?? throw new ArgumentException("Client repository is null");
        }
        public IEnumerable<PortalClient> GetAll()
        {
            return _clientRepo.GetAll();
        }
    }
}
