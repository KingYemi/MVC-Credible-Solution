﻿using Credible.Core.Interfaces;
using Credible.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Core.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepo;

        public UserService(IUserRepository userRepo)
        {
            _userRepo = userRepo ?? throw new ArgumentException("User repository is null");
        }
        public UserRegistrationRecords GetUsersByCourseId(int coursePortalId, int pageIdx, int maxRows, int totalRecords)
        {
            return _userRepo.GetUsersByCourseId(coursePortalId, pageIdx, maxRows, totalRecords);
        }
    }
}
