﻿using Credible.Core.Interfaces;
using Credible.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Core.Services
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _courseRepo;
        public CourseService(ICourseRepository courseRepo)
        {
            _courseRepo = courseRepo ?? throw new ArgumentException("Course repository is null");
        }

        public IEnumerable<Course> GetCoursesByPortalId(int portalId)
        {
            return _courseRepo.GetCoursesByPortalId(portalId);
        }
    }
}
