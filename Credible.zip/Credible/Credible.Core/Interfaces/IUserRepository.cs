﻿using Credible.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Core.Interfaces
{
    public interface IUserRepository
    {

        UserRegistrationRecords GetUsersByCourseId(int courseId, int page, int maxRows, int totalRecords);
    }
}
