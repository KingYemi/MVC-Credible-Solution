﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Credible.Core.Model
{
    public class UserRegistrationRecords
    {
        public  List<User> UserRecords { get; set; }
        public  int TotalRecords { get; set; }

        public UserRegistrationRecords()
        {
            UserRecords = new List<User>();
        }
    }

    public class User
    {
        public int UserId { get; set; }
        public int CoursePortalId { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }

        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [DisplayName("Registration Date")]
        public DateTime RegistrationDate { get; set; }
    }
}
